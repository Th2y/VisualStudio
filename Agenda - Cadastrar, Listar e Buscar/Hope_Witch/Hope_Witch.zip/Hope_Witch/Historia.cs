﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hope_Witch
{
    class Historia
    {
        private string falas;
        private string texto;

        public Historia()
        {
            this.falas = falas;
        }

        public string Falas
        {
            get
            {
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                for (int i = 0; i < texto.Length; i++)
                {
                    Console.Write(texto[i]);
                    Thread.Sleep(15);
                }
                return this.falas;
            }
        }

        public void Jogar()
        {
            Console.BackgroundColor = ConsoleColor.Gray;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("Chego na faculdade já atrasada, quem mandou ir dormir tarde tendo que acordar cedo no outro dia?");
            Console.WriteLine("Logo que entro na faculdade, percebo que já estão todos na sala, tenho que ir logo ou vou ficar com má fama logo no primeiro dia, e isso não dá!");
            Console.WriteLine("Já não basta ser uma bruxa que nem sabe fazer magia (eu tenho poderes, segundo os testes, mas não sei como usá-los). ");
            Console.WriteLine("Pouco antes de entrar na sala, percebo um cara chorando, sei que ele me viu olhando para ele");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("");
            Console.WriteLine("Todas as vezes que tiver um texto em amarelo, escolha uma das opções, teclando 1 para a primeira e 2 para a segunda");
            Console.WriteLine("");

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("1: Entro na sala e ignoro ele, já está tarde, ele deve me entender");
            Console.WriteLine("2: Falo com ele, já estou atrasada e nem queria vir mesmo");
            Console.WriteLine("");
            int resp1 = int.Parse(Console.ReadLine());
            if (resp1 == 1)
            {
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("Ainda bem! Percebi que o professor chegou junto comigo, vou tentar ficar no meu canto,");
                Console.Write(" quero só aprender os assuntos para sair o mais rápido possível desse lugar.");
                Console.WriteLine("Depois das apresentações, o professor logo começa o assunto, ele parece ser bom, mas esse assunto… ");
                Console.WriteLine("Descobrir qual a sua tarefa no mundo bruxo a partir dos bruxos mais famosos de todos os tempos. ");
                Console.Write("Não reconheci nenhum deles, chegando em casa vou estudar o dia todo só para entender");
                Console.WriteLine("Depois de muito estudar, só parando um pouquinho para comer e beber água, ");
                Console.Write("finalmente consigo entender o assunto, mas percebo que já está ficando tarde e vou dormir.");
                Console.WriteLine("~~Quase dormindo~~Espero que aquele cara esteja bem, queria ter falado com ele, mas… amanhã vou tentar falar com ele");
            }
            else if (resp1 == 2)
            {
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("-Oi, posso te fazer companhia?");
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("-Prefiro ficar sozinho, vá para a aula, não quero te atrapalhar");
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("-Não se preocupe com isso, depois eu procuro o assunto, mas o que aconteceu?");
                Thread.Sleep(150);
                Console.WriteLine("-Posso te ajudar em algo?");
                Thread.Sleep(150);
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("-Obrigado, mas não posso te contar, mas já que insiste, podemos conversar sobre outro assunto, vai ser bom esquecer um pouco");
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("-Tudo bem, qual o seu nome?");
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("-Omar Esdras, mas pode me chamar de Omar. E o seu?");
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("-Prazer Omar, sou a Lana Ravena, ou melhor, Lana");
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("-Prazer Lana, o professor está entrando agora, tem certeza de que não prefere ir para a aula também? ");
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("-Sim, não estou interessada em nada");
                Console.WriteLine("Conversamos durante um bom tempo, sobre a faculdade e nossas habilidades, então descubro estar diante do meu oposto: enquanto eu não consigo faze nem");
                Console.Write("uma pena se mover, ele consegue até a Terra inteira se brincar. Já no final da manhã, chega nosso mentor, perguntando o motivo de não estarmos na aula.");
                Console.Write("Explicamos, mas ainda levamos bronca, ele explicou que apesar de não sermos cobrados para permanecer nas aulas nem nada, como na escola, quem não");
                Console.Write("frequenta as aulas perde todos os assuntos e os professores de lá costumam fazer prova toda semana. Agradecemos pelos conselhos e nos despedimos, ");
                Console.Write("chegando em casa eu até poderia estudar, mas como, se nem saber o tema eu sei? Vou relaxar e continuar tentando fazer magia.");
                Console.Write(" Amanhã procuro saber");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Opção inválida");
            }
        }
        public void Sair()
        {
            Console.WriteLine("Para sair, basta apertar no X. Até breve!");
        }
    }
}