﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hope_Witch
{
    class Falas
    {
        string texto;
        public void ProtagonistaNarrando()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            for (int i = 0; i < texto.Length; i++)
            {
                Console.Write(texto[i]);
                Thread.Sleep(10);
            }
        }
        public void ProtagonistaFalando()
        {
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            for (int i = 0; i < texto.Length; i++)
            {
                Console.Write(texto[i]);
                Thread.Sleep(15);
            }
        }
        public void Antagonista()
        {
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            for (int i = 0; i < texto.Length; i++)
            {
                Console.Write(texto[i]);
                Thread.Sleep(15);
            }
        }
        public void Outros()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            for (int i = 0; i < texto.Length; i++)
            {
                Console.Write(texto[i]);
                Thread.Sleep(15);
            }
        }
    }
}
