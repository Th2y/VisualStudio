﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hope_Witch
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WindowWidth = 160; //Largura, vai ate 240
            Console.WindowHeight = 50; //Altura, vai ate 63

            Console.CursorVisible = false;
            Console.ForegroundColor = ConsoleColor.DarkMagenta;

            int delay = 200;
            Console.WriteLine();
            Console.WriteLine("                     ##     ##  #######  ########  ########    ##      ## #### ########  ######  ##     ## ");
            Thread.Sleep(delay);
            Console.WriteLine("                     ##     ## ##     ## ##     ## ##          ##  ##  ##  ##     ##    ##    ## ##     ## ");
            Thread.Sleep(delay);
            Console.WriteLine("                     ##     ## ##     ## ##     ## ##          ##  ##  ##  ##     ##    ##       ##     ## ");
            Thread.Sleep(delay);
            Console.WriteLine("                     ######### ##     ## ########  ######      ##  ##  ##  ##     ##    ##       ######### ");
            Thread.Sleep(delay);
            Console.WriteLine("                     ##     ## ##     ## ##        ##          ##  ##  ##  ##     ##    ##       ##     ## ");
            Thread.Sleep(delay);
            Console.WriteLine("                     ##     ## ##     ## ##        ##          ##  ##  ##  ##     ##    ##    ## ##     ## ");
            Thread.Sleep(delay);
            Console.WriteLine("                     ##     ##  #######  ##        ########     ###  ###  ####    ##     ######  ##     ## ");
            Thread.Sleep(delay);
            Console.WriteLine();
            Console.WriteLine("   --------------------------------------------------------------------------------------------------------------------------------");
            Thread.Sleep(delay * 10);
            Console.CursorVisible = true;

            Historia historia = new Historia();

            string[] opcoes = new string[] { "Jogar", "Sair"};
            int opcao = 0;
            Console.CursorVisible = false;
            while (true)
            {
                Console.Clear();

                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Utilizando as setas, selecione uma das opções abaixo:");

                for (int i = 0; i < opcoes.Length; i++)
                {
                    if (opcao == i)
                    {
                        Console.Write("[ ");
                        Console.Write(opcoes[0]);
                        Console.WriteLine(" ]");
                        Console.Write("[ ");
                        Console.Write(opcoes[1]);
                        Console.WriteLine(" ]");
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkGray;
                        Console.WriteLine(opcoes[i]);
                    }
                }

                ConsoleKeyInfo keyInfo = Console.ReadKey(false);
                Console.ResetColor();

                if (keyInfo.Key == ConsoleKey.UpArrow)
                {
                    if (opcao > 0)
                    {
                        opcao--;
                    }
                }
                else
                {
                    if (keyInfo.Key == ConsoleKey.DownArrow)
                    {
                        if (opcao < (opcoes.Length - 1))
                        {
                            opcao++;
                        }
                    }
                    else
                    {
                        if (keyInfo.Key == ConsoleKey.Enter)
                        {
                            switch (opcao)
                            {
                                case 0:
                                    Console.Clear();
                                    historia.Jogar();
                                    break;
                                case 1:
                                    historia.Sair();
                                    break;
                                default:
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("Opção inválida.");
                                    Console.ResetColor();
                                    break;
                            }

                            Console.WriteLine();
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("Pressione qualquer tecla para continuar...");
                            Console.ReadKey();
                            Console.Clear();
                        }
                    }
                }
            }
        }
    }
}
